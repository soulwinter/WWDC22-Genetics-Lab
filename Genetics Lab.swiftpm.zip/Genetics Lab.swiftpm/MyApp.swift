import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            // InstructionView(title: startTitle, instructionContent: startInstructionContent, factorAnimationOn: true, plants: startPlants)
            MainView()
        }
    }
}
